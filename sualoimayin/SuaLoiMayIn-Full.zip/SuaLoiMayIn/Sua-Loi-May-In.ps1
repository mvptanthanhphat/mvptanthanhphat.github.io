﻿# Sua loi may in - PhuocIT
# Gop: thay 3 file Spooler64, khoi phuc Print Spooler Error 2, va cac loi RPC/LAN/USB.
# Chay: chuot phai Sua-Loi-May-In.bat -> Run as administrator.
#Requires -Version 5.1
$ErrorActionPreference = "Continue"
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

$Root = $PSScriptRoot
if (-not $Root) { $Root = Split-Path -Parent $MyInvocation.MyCommand.Definition }
$Bundle = Join-Path $Root "Spooler64"
$Log = Join-Path $env:TEMP "SuaLoiMayIn.log"

$Expected = @{
  "spoolsv.exe"  = "7886F734A66D2FA9EF1B3E7F1B4677BC3259AD583FD64A1BFFD042DF3E7EF313"
  "localspl.dll" = "C2CB9B1E95EBAFD33F113159EAD5F1E5BEB55CACC9E05C4D45DB39138641CCA5"
  "win32spl.dll" = "5613D71C29D90BF46D525C71642D649E6F451F80902D9B96AE48FC8645D54671"
}
$FileOrder = @("spoolsv.exe", "localspl.dll", "win32spl.dll")

function Test-IsAdmin {
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  $principal = New-Object Security.Principal.WindowsPrincipal($id)
  return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-IsAdmin)) {
  Write-Host "Dang xin quyen Administrator..."
  Start-Process -FilePath "powershell.exe" -Verb RunAs -ArgumentList @(
    "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$PSCommandPath`""
  )
  exit
}

function Get-System32 {
  $windir = $env:SystemRoot
  if (-not $windir) { $windir = "C:\Windows" }
  $is64os = $false
  try { $is64os = [Environment]::Is64BitOperatingSystem } catch { $is64os = $true }
  $is64proc = $false
  try { $is64proc = [Environment]::Is64BitProcess } catch { $is64proc = $true }
  if ($is64os -and -not $is64proc) { return (Join-Path $windir "Sysnative") }
  return (Join-Path $windir "System32")
}

$Sys = Get-System32

function Write-Log([string]$Message) {
  $line = "[{0}] {1}" -f (Get-Date -Format "HH:mm:ss"), $Message
  Write-Host $line
  Add-Content -LiteralPath $Log -Value $line -Encoding UTF8
}

function Pause-Menu {
  Write-Host ""
  Read-Host "Nhan Enter de ve menu"
}

function Stop-SpoolerHard {
  Write-Log "Dung Print Spooler..."
  & sc.exe stop Spooler | Out-Null
  & net.exe stop spooler /y | Out-Null
  Start-Sleep -Seconds 1
  foreach ($image in @("spoolsv.exe", "splwow64.exe", "PrintIsolationHost.exe")) {
    & taskkill.exe /F /IM $image 2>$null | Out-Null
  }
  Start-Sleep -Seconds 2
}

function Start-SpoolerChecked {
  & sc.exe config Spooler "start=" "auto" | Out-Null
  & sc.exe start Spooler | Out-Null
  Start-Sleep -Seconds 3
  $query = (& sc.exe query Spooler | Out-String)
  $running = $query -match "RUNNING"
  if ($running) { Write-Log "Print Spooler dang RUNNING." }
  else { Write-Log "Print Spooler chua RUNNING." ; Write-Host $query }
  return $running
}

function Backup-SpoolerRegistry {
  $bak = Join-Path $env:TEMP ("Spooler_backup_{0}.reg" -f (Get-Date -Format "yyyyMMdd_HHmmss"))
  & reg.exe export "HKLM\SYSTEM\CurrentControlSet\Services\Spooler" $bak /y | Out-Null
  if (Test-Path -LiteralPath $bak) { Write-Log "Backup registry: $bak" }
  else { Write-Log "Khong xuat duoc registry Spooler (co the khoa chua ton tai)." }
}

function Restore-ServiceDefaults {
  Write-Log "Ghi cau hinh dich vu Spooler ve mac dinh Windows..."
  $key = "HKLM\SYSTEM\CurrentControlSet\Services\Spooler"
  & reg.exe add $key /v Start /t REG_DWORD /d 2 /f | Out-Null
  & reg.exe add $key /v Type /t REG_DWORD /d 272 /f | Out-Null
  & reg.exe add $key /v ErrorControl /t REG_DWORD /d 1 /f | Out-Null
  & reg.exe add $key /v ServiceSidType /t REG_DWORD /d 1 /f | Out-Null
  & reg.exe add $key /v ImagePath /t REG_EXPAND_SZ /d "%SystemRoot%\System32\spoolsv.exe" /f | Out-Null
  & reg.exe add $key /v DisplayName /t REG_SZ /d "@%systemroot%\system32\spoolsv.exe,-1" /f | Out-Null
  & reg.exe add $key /v Description /t REG_SZ /d "@%systemroot%\system32\spoolsv.exe,-2" /f | Out-Null
  & reg.exe add $key /v ObjectName /t REG_SZ /d "LocalSystem" /f | Out-Null
  & reg.exe add $key /v Group /t REG_SZ /d "SpoolerGroup" /f | Out-Null
  & reg.exe add $key /v DependOnService /t REG_MULTI_SZ /d "RPCSS\0http\0" /f | Out-Null
  & reg.exe add $key /v RequiredPrivileges /t REG_MULTI_SZ /d "SeTcbPrivilege\0SeImpersonatePrivilege\0SeAuditPrivilege\0SeChangeNotifyPrivilege\0SeAssignPrimaryTokenPrivilege\0SeLoadDriverPrivilege\0SeSystemEnvironmentPrivilege\0" /f | Out-Null
  & sc.exe config Spooler "start=" "auto" | Out-Null
  & sc.exe config Spooler "binPath=" "%SystemRoot%\System32\spoolsv.exe" | Out-Null
  & sc.exe config Spooler "obj=" "LocalSystem" | Out-Null
  & sc.exe config Spooler "depend=" "RPCSS/http" | Out-Null
  & sc.exe config Spooler "error=" "normal" | Out-Null
  & sc.exe config Spooler "group=" "SpoolerGroup" | Out-Null
  & sc.exe failure Spooler "reset=" "86400" "actions=" "restart/60000/restart/60000/restart/60000" | Out-Null
  & sc.exe failureflag Spooler 1 | Out-Null

  $perf = "$key\Performance"
  & reg.exe add $perf /v Close /t REG_SZ /d "PerfClose" /f | Out-Null
  & reg.exe add $perf /v Open /t REG_SZ /d "PerfOpen" /f | Out-Null
  & reg.exe add $perf /v Collect /t REG_SZ /d "PerfCollect" /f | Out-Null
  & reg.exe add $perf /v Library /t REG_EXPAND_SZ /d "%SystemRoot%\System32\winspool.drv" /f | Out-Null
  & reg.exe add $perf /v "Object List" /t REG_SZ /d "1450" /f | Out-Null
  Write-Log "ImagePath, Description, Type=272, Start=Automatic, depend=RPCSS+http."
}

function Repair-PrintStack {
  if (Test-Path -LiteralPath (Join-Path $Sys "localspl.dll")) {
    & reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\Print\Monitors\Local Port" /v Driver /t REG_SZ /d "localspl.dll" /f | Out-Null
    & reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\Print\Environments\Windows x64\Print Processors\winprint" /v Driver /t REG_SZ /d "localspl.dll" /f | Out-Null
    & reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\Print\Environments\Windows NT x86\Print Processors\winprint" /v Driver /t REG_SZ /d "localspl.dll" /f | Out-Null
  }
  foreach ($rel in @("spool\PRINTERS", "spool\SERVERS", "spool\drivers")) {
    $dir = Join-Path $Sys $rel
    if (-not (Test-Path -LiteralPath $dir)) {
      New-Item -ItemType Directory -Path $dir -Force | Out-Null
      Write-Log "Tao thu muc $rel"
    }
  }
}

function Set-RpcPolicy {
  Write-Log "Khoa RPC va Point and Print..."
  & reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\Print" /v RpcAuthnLevelPrivacyEnabled /t REG_DWORD /d 0 /f | Out-Null
  & reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Printers\RPC" /v RpcOverNamedPipes /t REG_DWORD /d 1 /f | Out-Null
  & reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Printers\RPC" /v RpcOverTcp /t REG_DWORD /d 1 /f | Out-Null
  & reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Printers\PointAndPrint" /v RestrictDriverInstallationToAdministrators /t REG_DWORD /d 0 /f | Out-Null
  & reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Printers\PointAndPrint" /v NoWarningNoElevationOnInstall /t REG_DWORD /d 1 /f | Out-Null
  & reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Printers\PointAndPrint" /v UpdatePromptSettings /t REG_DWORD /d 2 /f | Out-Null
}

function Open-PrinterFirewall {
  # Ma nhom, khong phu thuoc ngon ngu Windows (tieng Viet hay tieng Anh).
  & netsh.exe advfirewall firewall set rule group="@FirewallAPI.dll,-28502" new enable=Yes | Out-Null
  & netsh.exe advfirewall firewall set rule group="@FirewallAPI.dll,-32752" new enable=Yes | Out-Null
  Write-Log "Da bat File and Printer Sharing va Network Discovery."
}

function Clear-PrintQueue {
  $dir = Join-Path $Sys "spool\PRINTERS"
  if (Test-Path -LiteralPath $dir) {
    Get-ChildItem -LiteralPath $dir -File -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
    Write-Log "Da xoa hang doi trong spool\PRINTERS. Driver giu nguyen."
  }
}

function Test-BundleFile([string]$Name) {
  $src = Join-Path $Bundle $Name
  if (-not (Test-Path -LiteralPath $src)) {
    Write-Log "THIEU $src"
    return $false
  }
  $bytes = [System.IO.File]::ReadAllBytes($src)
  if ($bytes.Length -lt 1024 -or $bytes[0] -ne 77 -or $bytes[1] -ne 90) {
    Write-Log "$Name khong phai file PE."
    return $false
  }
  $sha = [System.BitConverter]::ToString([System.Security.Cryptography.SHA256]::Create().ComputeHash($bytes)).Replace("-", "")
  $want = $Expected[$Name]
  if ($sha -ne $want) {
    Write-Log "SAI SHA-256 $Name. Khong ghi file la."
    return $false
  }
  return $true
}

function Grant-SystemFile([string]$Path) {
  if (-not (Test-Path -LiteralPath $Path)) { return }
  & takeown.exe /A /F $Path | Out-Null
  & icacls.exe $Path /grant "*S-1-5-32-544:F" /C | Out-Null
  & icacls.exe $Path /grant "*S-1-5-18:F" /C | Out-Null
  & attrib.exe -R -S -H $Path | Out-Null
}

function Copy-BundleFiles {
  $allOk = $true
  foreach ($name in $FileOrder) {
    if (-not (Test-BundleFile $name)) { $allOk = $false; continue }
    $src = Join-Path $Bundle $name
    $dst = Join-Path $Sys $name
    $old = "$dst.old"
    $renamed = $false
    if (Test-Path -LiteralPath $dst) {
      Grant-SystemFile $dst
      if (Test-Path -LiteralPath $old) {
        Grant-SystemFile $old
        Remove-Item -LiteralPath $old -Force -ErrorAction SilentlyContinue
      }
      try {
        Rename-Item -LiteralPath $dst -NewName "$name.old" -ErrorAction Stop
        $renamed = $true
        Write-Log "Doi $name thanh $name.old"
      } catch {
        try {
          Copy-Item -LiteralPath $dst -Destination $old -Force -ErrorAction Stop
          Write-Log "Khong doi ten duoc $name, da copy ra .old"
        } catch {
          Write-Log "Khong backup duoc ${name}: $($_.Exception.Message)"
        }
      }
    }
    try {
      if (Test-Path -LiteralPath $dst) { Grant-SystemFile $dst }
      [System.IO.File]::Copy($src, $dst, $true)
      $size = (Get-Item -LiteralPath $dst).Length
      Write-Log "Da thay $name ($size bytes)."
    } catch {
      Write-Log "Copy that bai ${name}: $($_.Exception.Message)"
      if ($renamed -and (Test-Path -LiteralPath $old) -and -not (Test-Path -LiteralPath $dst)) {
        Rename-Item -LiteralPath $old -NewName $name -ErrorAction SilentlyContinue
        Write-Log "Da doi nguoc $name.old vi copy loi."
      }
      if (-not (Test-Path -LiteralPath $dst)) { $allOk = $false }
    }
  }
  return $allOk
}

function Restore-OldFiles {
  foreach ($name in $FileOrder) {
    $dst = Join-Path $Sys $name
    $old = "$dst.old"
    if (-not (Test-Path -LiteralPath $old)) { continue }
    try {
      Grant-SystemFile $dst
      [System.IO.File]::Copy($old, $dst, $true)
      Write-Log "Tra lai ban cu $name"
    } catch {
      Write-Log "Khong tra duoc ${name}: $($_.Exception.Message)"
    }
  }
}

function Ensure-HttpDriver {
  $raw = & reg.exe query "HKLM\SYSTEM\CurrentControlSet\Services\HTTP" /v Start 2>$null | Out-String
  if ($raw -match "0x4") {
    Write-Log "HTTP dang Disabled. Dat lai Demand."
    & sc.exe config HTTP "start=" "demand" | Out-Null
  }
  & sc.exe start HTTP | Out-Null
  & sc.exe start RPCSS | Out-Null
}

function Invoke-ChacChan {
  Write-Log "===== SUA CHAC CHAN ====="
  $os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
  if ($os) { Write-Log ("Windows {0} build {1}" -f $os.Caption, $os.BuildNumber) }
  if ($os -and [int]$os.BuildNumber -ge 22000) {
    Write-Log "Day la Windows 11. File Spooler64 la Windows 10 19041. Neu khong len, tool se tra file .old."
  }
  Backup-SpoolerRegistry
  Stop-SpoolerHard
  $copied = Copy-BundleFiles
  if (-not $copied) { Write-Log "Co file khong thay duoc. Van ghi registry va thu start." }
  Restore-ServiceDefaults
  Repair-PrintStack
  Set-RpcPolicy
  Open-PrinterFirewall
  Clear-PrintQueue
  Ensure-HttpDriver
  if (Start-SpoolerChecked) {
    Write-Log "XONG. Doi khoang 2 phut roi ket noi lai may in."
    return
  }
  Write-Log "Ban moi khong chay. Dang tra file .old..."
  Stop-SpoolerHard
  Restore-OldFiles
  Restore-ServiceDefaults
  if (Start-SpoolerChecked) {
    Write-Log "Da tra file cu va spooler RUNNING. Loi nam o cho khac, khong phai 3 file nay."
  } else {
    Write-Log "Van chua chay. Khoi dong lai may, chay menu 1 lan nua. Log: $Log"
  }
}

function Invoke-FilesOnly {
  Write-Log "===== CHI THAY 3 FILE ====="
  Stop-SpoolerHard
  Copy-BundleFiles | Out-Null
  if (Start-SpoolerChecked) { Write-Log "XONG. Doi khoang 2 phut roi ket noi may in." }
  else { Write-Log "Chua len. Chay menu 1 de ghi luon registry Error 2." }
}

function Invoke-Error2 {
  Write-Log "===== ERROR 2 / DESCRIPTION ====="
  Backup-SpoolerRegistry
  Stop-SpoolerHard
  Restore-ServiceDefaults
  Repair-PrintStack
  Ensure-HttpDriver
  Start-SpoolerChecked | Out-Null
}

function Invoke-Rpc {
  Write-Log "===== RPC 0x11b / 0x7c / 0xbc4 ====="
  Set-RpcPolicy
  Stop-SpoolerHard
  Start-SpoolerChecked | Out-Null
}

function Invoke-Firewall {
  Write-Log "===== FIREWALL ====="
  & sc.exe config MpsSvc "start=" "auto" | Out-Null
  & sc.exe start MpsSvc | Out-Null
  Open-PrinterFirewall
}

function Invoke-ShareAll {
  Write-Log "===== CHIA SE MAY IN ====="
  $printers = @(Get-CimInstance -ClassName Win32_Printer -ErrorAction SilentlyContinue)
  if ($printers.Count -eq 0) { Write-Log "Khong tim thay may in."; return }
  foreach ($printer in $printers) {
    $share = -join ($printer.Name.ToCharArray() | Where-Object { $_ -match "[A-Za-z0-9_-]" })
    if ($share.Length -gt 12) { $share = $share.Substring(0, 12) }
    if (-not $share) { $share = "Printer" }
    Write-Log ("{0} => {1}" -f $printer.Name, $share)
    & rundll32.exe "printui.dll,PrintUIEntry" "/Xs" "/n" "$($printer.Name)" "Shared" "TRUE" "ShareName" "$share"
  }
}

function Invoke-709 {
  Write-Log "===== 0x00000709 ====="
  $win = "HKCU:\Software\Microsoft\Windows NT\CurrentVersion\Windows"
  try {
    $acl = Get-Acl $win
    $everyone = New-Object System.Security.Principal.SecurityIdentifier("S-1-1-0")
    $rule = New-Object System.Security.AccessControl.RegistryAccessRule(
      $everyone, "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")
    $acl.SetAccessRule($rule)
    Set-Acl -Path $win -AclObject $acl
    Write-Log "Da cap quyen khoa Windows cua user hien tai."
  } catch {
    Write-Log "Khong doi duoc ACL: $($_.Exception.Message)"
  }
  & reg.exe delete "HKCU\Software\Microsoft\Windows NT\CurrentVersion\Windows" /v Device /f | Out-Null
  & reg.exe add "HKCU\Software\Microsoft\Windows NT\CurrentVersion\Windows" /v LegacyDefaultPrinterMode /t REG_DWORD /d 1 /f | Out-Null
  Stop-SpoolerHard
  Start-SpoolerChecked | Out-Null
  Write-Log "Vao Settings dat lai may in mac dinh."
}

function Invoke-Policy {
  Write-Log "===== POINT AND PRINT ====="
  $k = "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Printers\PointAndPrint"
  & reg.exe add $k /v RestrictDriverInstallationToAdministrators /t REG_DWORD /d 0 /f | Out-Null
  & reg.exe add $k /v NoWarningNoElevationOnInstall /t REG_DWORD /d 1 /f | Out-Null
  & reg.exe add $k /v UpdatePromptSettings /t REG_DWORD /d 2 /f | Out-Null
  & reg.exe add $k /v InForest /t REG_DWORD /d 0 /f | Out-Null
  Stop-SpoolerHard
  Start-SpoolerChecked | Out-Null
}

function Invoke-LocalLink {
  Write-Log "===== 0x3e3 / LOCAL CONNECTION ====="
  & reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\Lsa" /v forceguest /t REG_DWORD /d 0 /f | Out-Null
  & reg.exe add "HKLM\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters" /v AllowInsecureGuestAuth /t REG_DWORD /d 1 /f | Out-Null
  Set-RpcPolicy
  Stop-SpoolerHard
  Start-SpoolerChecked | Out-Null
}

function Invoke-NetResource {
  Write-Log "===== 0xbcb ====="
  foreach ($svc in @("LanmanWorkstation", "LanmanServer")) {
    & sc.exe config $svc "start=" "auto" | Out-Null
    & sc.exe start $svc | Out-Null
  }
  Open-PrinterFirewall
  Stop-SpoolerHard
  Start-SpoolerChecked | Out-Null
}

function Copy-Mscms {
  $src = Join-Path $Sys "mscms.dll"
  foreach ($rel in @("spool\drivers\x64\3", "spool\drivers\w32x86\3")) {
    $dir = Join-Path $Sys $rel
    $dst = Join-Path $dir "mscms.dll"
    if ((Test-Path -LiteralPath $src) -and (Test-Path -LiteralPath $dir) -and -not (Test-Path -LiteralPath $dst)) {
      Copy-Item -LiteralPath $src -Destination $dst -Force
      Write-Log "Copy mscms.dll -> $rel"
    }
  }
}

function Invoke-DriverAndQueue {
  Write-Log "===== 0x7e / HANG DOI ====="
  Stop-SpoolerHard
  Copy-Mscms
  Clear-PrintQueue
  & sc.exe config Spooler "start=" "auto" | Out-Null
  Start-SpoolerChecked | Out-Null
}

function Invoke-RpcServices {
  Write-Log "===== 0x6ba ====="
  foreach ($svc in @("RpcSs", "RpcEptMapper")) {
    & sc.exe config $svc "start=" "auto" | Out-Null
    & sc.exe start $svc | Out-Null
  }
  Set-RpcPolicy
  Stop-SpoolerHard
  Start-SpoolerChecked | Out-Null
}

function Invoke-Offline {
  Write-Log "===== 0x771 OFFLINE ====="
  Get-WmiObject -Class Win32_Printer -ErrorAction SilentlyContinue |
    Where-Object { $_.WorkOffline -eq $true } |
    ForEach-Object {
      $_.WorkOffline = $false
      $_.Put() | Out-Null
      Write-Log "Da online: $($_.Name)"
    }
  Stop-SpoolerHard
  Clear-PrintQueue
  Start-SpoolerChecked | Out-Null
}

function Invoke-DismPrint {
  Write-Log "===== 0x3eb DISM ====="
  & dism.exe /Online /Enable-Feature /FeatureName:Printing-Foundation-InternetPrinting-Client /NoRestart
  & dism.exe /Online /Enable-Feature /FeatureName:Printing-LPRPortMonitor /NoRestart
  & dism.exe /Online /Enable-Feature /FeatureName:Printing-Foundation-LPDPrintService /NoRestart
  Stop-SpoolerHard
  Start-SpoolerChecked | Out-Null
}

function Invoke-Canon {
  Write-Log "===== CANON LBP ====="
  Stop-SpoolerHard
  Clear-PrintQueue
  & reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\Print\Monitors\USB Monitor" /f | Out-Null
  $base = "HKLM:\SYSTEM\CurrentControlSet\Control\Print\Monitors"
  Get-ChildItem -LiteralPath $base -ErrorAction SilentlyContinue |
    Where-Object { $_.PSChildName -match "CNBJNP" } |
    ForEach-Object {
      Remove-Item -LiteralPath $_.PSPath -Recurse -Force -ErrorAction SilentlyContinue
      Write-Log "Xoa $($_.PSChildName)"
    }
  Copy-Mscms
  Start-SpoolerChecked | Out-Null
  Write-Log "Rut cap USB, doi 10 giay, cam lai."
}

function Invoke-ResetPorts {
  Write-Log "===== CONG TCP/IP HONG ====="
  $path = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Ports"
  $item = Get-ItemProperty -Path $path -ErrorAction SilentlyContinue
  if (-not $item) { Write-Log "Khong mo duoc khoa Ports."; return }
  $safe = @("usb", "lpt", "com", "file:", "nul", "portprompt", "xps")
  $removed = 0
  foreach ($prop in $item.PSObject.Properties) {
    $name = [string]$prop.Name
    if ($name.StartsWith("PS")) { continue }
    $low = $name.ToLowerInvariant()
    $keep = $false
    foreach ($prefix in $safe) {
      if ($low.StartsWith($prefix)) { $keep = $true }
    }
    if ($keep) { continue }
    if ($name.Contains(".") -or $name.Contains("\")) {
      Remove-ItemProperty -Path $path -Name $name -ErrorAction SilentlyContinue
      Write-Log "Xoa cong $name"
      $removed++
    }
  }
  Write-Log "Da xoa $removed cong. USB/COM/LPT giu nguyen."
  Stop-SpoolerHard
  Start-SpoolerChecked | Out-Null
}

function Invoke-UnlockShare {
  Write-Log "===== MO KHOA CHIA SE ====="
  & reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Printers" /v DisableHTTPPrinting /t REG_DWORD /d 0 /f | Out-Null
  & reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Printers" /v DisablePrinterAdmin /t REG_DWORD /d 0 /f | Out-Null
  Invoke-Policy
}

function Invoke-Diagnose {
  Write-Log "===== CHAN DOAN ====="
  $os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
  if ($os) { Write-Log ("May: {0} | {1} | build {2}" -f $env:COMPUTERNAME, $os.Caption, $os.BuildNumber) }
  Write-Log "System32: $Sys"
  foreach ($name in $FileOrder) {
    $path = Join-Path $Sys $name
    if (-not (Test-Path -LiteralPath $path)) { Write-Log "THIEU $name"; continue }
    $item = Get-Item -LiteralPath $path
    $head = [System.IO.File]::ReadAllBytes($path)[0..1]
    $mz = ($head[0] -eq 77 -and $head[1] -eq 90)
    $ver = $item.VersionInfo.FileVersion
    Write-Log ("{0}  {1} bytes  MZ={2}  {3}" -f $name, $item.Length, $mz, $ver)
  }
  Write-Host (& sc.exe query Spooler | Out-String)
  Write-Host (& sc.exe qc Spooler | Out-String)
  & reg.exe query "HKLM\SYSTEM\CurrentControlSet\Services\Spooler" /v ImagePath
  & reg.exe query "HKLM\SYSTEM\CurrentControlSet\Control\Print" /v RpcAuthnLevelPrivacyEnabled
  Write-Log "Log day du: $Log"
}

"" | Set-Content -LiteralPath $Log -Encoding UTF8
Write-Log "Sua loi may in | $env:COMPUTERNAME | $env:USERNAME"

while ($true) {
  Write-Host ""
  Write-Host "============================================================"
  Write-Host "  SUA LOI MAY IN"
  Write-Host "  1  Sua chac chan   (3 file + Error 2 + RPC + firewall)"
  Write-Host "  2  Chi thay 3 file Spooler64"
  Write-Host "  3  Error 2 / Failed to Read Description"
  Write-Host "  4  0x11b / 0x7c / 0xbc4   RPC"
  Write-Host "  5  0x6d9 / 0x40          Firewall"
  Write-Host "  6  Chia se tat ca may in"
  Write-Host "  7  0x709                May in mac dinh"
  Write-Host "  8  Policy Point and Print / 0x4005"
  Write-Host "  9  0x3e3                Workgroup"
  Write-Host "  10 0xbcb                Tai nguyen mang"
  Write-Host "  11 0x7e                 Driver / mscms + hang doi"
  Write-Host "  12 Hang doi ket         (ca 0x12)"
  Write-Host "  13 0x6ba                RPCSS"
  Write-Host "  14 0x771                May in Offline"
  Write-Host "  15 0x3eb                DISM Printing"
  Write-Host "  16 Canon LBP 2900/3300"
  Write-Host "  17 Xoa cong TCP/IP hong"
  Write-Host "  18 Mo khoa chia se"
  Write-Host "  19 Chan doan            (chua sua)"
  Write-Host "  0  Thoat"
  Write-Host "============================================================"
  $choice = Read-Host "Chon"
  switch ($choice) {
    "1" { Invoke-ChacChan; Pause-Menu }
    "2" { Invoke-FilesOnly; Pause-Menu }
    "3" { Invoke-Error2; Pause-Menu }
    "4" { Invoke-Rpc; Pause-Menu }
    "5" { Invoke-Firewall; Pause-Menu }
    "6" { Invoke-ShareAll; Pause-Menu }
    "7" { Invoke-709; Pause-Menu }
    "8" { Invoke-Policy; Pause-Menu }
    "9" { Invoke-LocalLink; Pause-Menu }
    "10" { Invoke-NetResource; Pause-Menu }
    "11" { Invoke-DriverAndQueue; Pause-Menu }
    "12" { Invoke-DriverAndQueue; Pause-Menu }
    "13" { Invoke-RpcServices; Pause-Menu }
    "14" { Invoke-Offline; Pause-Menu }
    "15" { Invoke-DismPrint; Pause-Menu }
    "16" { Invoke-Canon; Pause-Menu }
    "17" { Invoke-ResetPorts; Pause-Menu }
    "18" { Invoke-UnlockShare; Pause-Menu }
    "19" { Invoke-Diagnose; Pause-Menu }
    "0" { exit 0 }
    default { Write-Host "Khong co muc nay." }
  }
}
