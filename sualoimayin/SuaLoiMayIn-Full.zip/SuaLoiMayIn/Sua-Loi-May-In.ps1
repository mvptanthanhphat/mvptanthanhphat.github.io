﻿# Tân Thành Phát - Sửa lỗi máy in
# Gop: thay 3 file Spooler64, khoi phuc Print Spooler Error 2, va cac loi RPC/LAN/USB.
# Chay: chuot phai Sua-Loi-May-In.bat -> Run as administrator.
#Requires -Version 5.1
$ErrorActionPreference = "Continue"
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

$Root = $PSScriptRoot
if (-not $Root) { $Root = Split-Path -Parent $MyInvocation.MyCommand.Definition }
$Bundle = Join-Path $Root "Spooler64"
$Log = Join-Path $env:TEMP "SuaLoiMayIn.log"

$Expected = @{
  "spoolsv.exe"  = "7886F734A66D2FA9EF1B3E7F1B4677BC3259AD583FD64A1BFFD042DF3E7EF313"
  "localspl.dll" = "C2CB9B1E95EBAFD33F113159EAD5F1E5BEB55CACC9E05C4D45DB39138641CCA5"
  "win32spl.dll" = "5613D71C29D90BF46D525C71642D649E6F451F80902D9B96AE48FC8645D54671"
}
$FileOrder = @("spoolsv.exe", "localspl.dll", "win32spl.dll")

function Test-IsAdmin {
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  $principal = New-Object Security.Principal.WindowsPrincipal($id)
  return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-IsAdmin)) {
  Write-Host "Dang xin quyen Administrator..."
  Start-Process -FilePath "powershell.exe" -Verb RunAs -ArgumentList @(
    "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$PSCommandPath`""
  )
  exit
}

function Get-System32 {
  $windir = $env:SystemRoot
  if (-not $windir) { $windir = "C:\Windows" }
  $is64os = $false
  try { $is64os = [Environment]::Is64BitOperatingSystem } catch { $is64os = $true }
  $is64proc = $false
  try { $is64proc = [Environment]::Is64BitProcess } catch { $is64proc = $true }
  if ($is64os -and -not $is64proc) { return (Join-Path $windir "Sysnative") }
  return (Join-Path $windir "System32")
}

$Sys = Get-System32

function Write-Log([string]$Message) {
  $line = "[{0}] {1}" -f (Get-Date -Format "HH:mm:ss"), $Message
  Write-Host $line
  Add-Content -LiteralPath $Log -Value $line -Encoding UTF8
}

function Pause-Menu {
  Write-Host ""
  Read-Host "Nhan Enter de ve menu"
}

function Stop-SpoolerHard {
  Write-Log "Dung Print Spooler..."
  & sc.exe stop Spooler | Out-Null
  & net.exe stop spooler /y | Out-Null
  Start-Sleep -Seconds 1
  foreach ($image in @("spoolsv.exe", "splwow64.exe", "PrintIsolationHost.exe")) {
    & taskkill.exe /F /IM $image 2>$null | Out-Null
  }
  Start-Sleep -Seconds 2
}

function Start-SpoolerChecked {
  & sc.exe config Spooler "start=" "auto" | Out-Null
  & sc.exe start Spooler | Out-Null
  Start-Sleep -Seconds 3
  $query = (& sc.exe query Spooler | Out-String)
  $running = $query -match "RUNNING"
  if ($running) { Write-Log "Print Spooler dang RUNNING." }
  else { Write-Log "Print Spooler chua RUNNING." ; Write-Host $query }
  return $running
}

function Backup-SpoolerRegistry {
  $bak = Join-Path $env:TEMP ("Spooler_backup_{0}.reg" -f (Get-Date -Format "yyyyMMdd_HHmmss"))
  & reg.exe export "HKLM\SYSTEM\CurrentControlSet\Services\Spooler" $bak /y | Out-Null
  if (Test-Path -LiteralPath $bak) { Write-Log "Backup registry: $bak" }
  else { Write-Log "Khong xuat duoc registry Spooler (co the khoa chua ton tai)." }
}

function Restore-ServiceDefaults {
  Write-Log "Ghi cau hinh dich vu Spooler ve mac dinh Windows..."
  $key = "HKLM\SYSTEM\CurrentControlSet\Services\Spooler"
  & reg.exe add $key /v Start /t REG_DWORD /d 2 /f | Out-Null
  & reg.exe add $key /v Type /t REG_DWORD /d 272 /f | Out-Null
  & reg.exe add $key /v ErrorControl /t REG_DWORD /d 1 /f | Out-Null
  & reg.exe add $key /v ServiceSidType /t REG_DWORD /d 1 /f | Out-Null
  & reg.exe add $key /v ImagePath /t REG_EXPAND_SZ /d "%SystemRoot%\System32\spoolsv.exe" /f | Out-Null
  & reg.exe add $key /v DisplayName /t REG_SZ /d "@%systemroot%\system32\spoolsv.exe,-1" /f | Out-Null
  & reg.exe add $key /v Description /t REG_SZ /d "@%systemroot%\system32\spoolsv.exe,-2" /f | Out-Null
  & reg.exe add $key /v ObjectName /t REG_SZ /d "LocalSystem" /f | Out-Null
  & reg.exe add $key /v Group /t REG_SZ /d "SpoolerGroup" /f | Out-Null
  & reg.exe add $key /v DependOnService /t REG_MULTI_SZ /d "RPCSS\0http\0" /f | Out-Null
  & reg.exe add $key /v RequiredPrivileges /t REG_MULTI_SZ /d "SeTcbPrivilege\0SeImpersonatePrivilege\0SeAuditPrivilege\0SeChangeNotifyPrivilege\0SeAssignPrimaryTokenPrivilege\0SeLoadDriverPrivilege\0SeSystemEnvironmentPrivilege\0" /f | Out-Null
  & sc.exe config Spooler "start=" "auto" | Out-Null
  & sc.exe config Spooler "binPath=" "%SystemRoot%\System32\spoolsv.exe" | Out-Null
  & sc.exe config Spooler "obj=" "LocalSystem" | Out-Null
  & sc.exe config Spooler "depend=" "RPCSS/http" | Out-Null
  & sc.exe config Spooler "error=" "normal" | Out-Null
  & sc.exe config Spooler "group=" "SpoolerGroup" | Out-Null
  & sc.exe failure Spooler "reset=" "86400" "actions=" "restart/60000/restart/60000/restart/60000" | Out-Null
  & sc.exe failureflag Spooler 1 | Out-Null

  $perf = "$key\Performance"
  & reg.exe add $perf /v Close /t REG_SZ /d "PerfClose" /f | Out-Null
  & reg.exe add $perf /v Open /t REG_SZ /d "PerfOpen" /f | Out-Null
  & reg.exe add $perf /v Collect /t REG_SZ /d "PerfCollect" /f | Out-Null
  & reg.exe add $perf /v Library /t REG_EXPAND_SZ /d "%SystemRoot%\System32\winspool.drv" /f | Out-Null
  & reg.exe add $perf /v "Object List" /t REG_SZ /d "1450" /f | Out-Null
  Write-Log "ImagePath, Description, Type=272, Start=Automatic, depend=RPCSS+http."
}

function Repair-PrintStack {
  if (Test-Path -LiteralPath (Join-Path $Sys "localspl.dll")) {
    & reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\Print\Monitors\Local Port" /v Driver /t REG_SZ /d "localspl.dll" /f | Out-Null
    & reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\Print\Environments\Windows x64\Print Processors\winprint" /v Driver /t REG_SZ /d "localspl.dll" /f | Out-Null
    & reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\Print\Environments\Windows NT x86\Print Processors\winprint" /v Driver /t REG_SZ /d "localspl.dll" /f | Out-Null
  }
  foreach ($rel in @("spool\PRINTERS", "spool\SERVERS", "spool\drivers")) {
    $dir = Join-Path $Sys $rel
    if (-not (Test-Path -LiteralPath $dir)) {
      New-Item -ItemType Directory -Path $dir -Force | Out-Null
      Write-Log "Tao thu muc $rel"
    }
  }
}

function Set-RpcPolicy {
  Write-Log "Khoa RPC va Point and Print..."
  & reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\Print" /v RpcAuthnLevelPrivacyEnabled /t REG_DWORD /d 0 /f | Out-Null
  & reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Printers\RPC" /v RpcOverNamedPipes /t REG_DWORD /d 1 /f | Out-Null
  & reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Printers\RPC" /v RpcOverTcp /t REG_DWORD /d 1 /f | Out-Null
  & reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Printers\PointAndPrint" /v RestrictDriverInstallationToAdministrators /t REG_DWORD /d 0 /f | Out-Null
  & reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Printers\PointAndPrint" /v NoWarningNoElevationOnInstall /t REG_DWORD /d 1 /f | Out-Null
  & reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Printers\PointAndPrint" /v UpdatePromptSettings /t REG_DWORD /d 2 /f | Out-Null
}

function Open-PrinterFirewall {
  # Ma nhom, khong phu thuoc ngon ngu Windows (tieng Viet hay tieng Anh).
  & netsh.exe advfirewall firewall set rule group="@FirewallAPI.dll,-28502" new enable=Yes | Out-Null
  & netsh.exe advfirewall firewall set rule group="@FirewallAPI.dll,-32752" new enable=Yes | Out-Null
  Write-Log "Da bat File and Printer Sharing va Network Discovery."
}

function Clear-PrintQueue {
  $dir = Join-Path $Sys "spool\PRINTERS"
  if (Test-Path -LiteralPath $dir) {
    Get-ChildItem -LiteralPath $dir -File -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
    Write-Log "Da xoa hang doi trong spool\PRINTERS. Driver giu nguyen."
  }
}

function Test-BundleFile([string]$Name) {
  $src = Join-Path $Bundle $Name
  if (-not (Test-Path -LiteralPath $src)) {
    Write-Log "THIEU $src"
    return $false
  }
  $bytes = [System.IO.File]::ReadAllBytes($src)
  if ($bytes.Length -lt 1024 -or $bytes[0] -ne 77 -or $bytes[1] -ne 90) {
    Write-Log "$Name khong phai file PE."
    return $false
  }
  $sha = [System.BitConverter]::ToString([System.Security.Cryptography.SHA256]::Create().ComputeHash($bytes)).Replace("-", "")
  $want = $Expected[$Name]
  if ($sha -ne $want) {
    Write-Log "SAI SHA-256 $Name. Khong ghi file la."
    return $false
  }
  return $true
}

function Grant-SystemFile([string]$Path) {
  if (-not (Test-Path -LiteralPath $Path)) { return }
  & takeown.exe /A /F $Path | Out-Null
  & icacls.exe $Path /grant "*S-1-5-32-544:F" /C | Out-Null
  & icacls.exe $Path /grant "*S-1-5-18:F" /C | Out-Null
  & attrib.exe -R -S -H $Path | Out-Null
}

function Copy-BundleFiles {
  $allOk = $true
  foreach ($name in $FileOrder) {
    if (-not (Test-BundleFile $name)) { $allOk = $false; continue }
    $src = Join-Path $Bundle $name
    $dst = Join-Path $Sys $name
    $old = "$dst.old"
    $renamed = $false
    if (Test-Path -LiteralPath $dst) {
      Grant-SystemFile $dst
      if (Test-Path -LiteralPath $old) {
        Grant-SystemFile $old
        Remove-Item -LiteralPath $old -Force -ErrorAction SilentlyContinue
      }
      try {
        Rename-Item -LiteralPath $dst -NewName "$name.old" -ErrorAction Stop
        $renamed = $true
        Write-Log "Doi $name thanh $name.old"
      } catch {
        try {
          Copy-Item -LiteralPath $dst -Destination $old -Force -ErrorAction Stop
          Write-Log "Khong doi ten duoc $name, da copy ra .old"
        } catch {
          Write-Log "Khong backup duoc ${name}: $($_.Exception.Message)"
        }
      }
    }
    try {
      if (Test-Path -LiteralPath $dst) { Grant-SystemFile $dst }
      [System.IO.File]::Copy($src, $dst, $true)
      $size = (Get-Item -LiteralPath $dst).Length
      Write-Log "Da thay $name ($size bytes)."
    } catch {
      Write-Log "Copy that bai ${name}: $($_.Exception.Message)"
      if ($renamed -and (Test-Path -LiteralPath $old) -and -not (Test-Path -LiteralPath $dst)) {
        Rename-Item -LiteralPath $old -NewName $name -ErrorAction SilentlyContinue
        Write-Log "Da doi nguoc $name.old vi copy loi."
      }
      if (-not (Test-Path -LiteralPath $dst)) { $allOk = $false }
    }
  }
  return $allOk
}

function Restore-OldFiles {
  foreach ($name in $FileOrder) {
    $dst = Join-Path $Sys $name
    $old = "$dst.old"
    if (-not (Test-Path -LiteralPath $old)) { continue }
    try {
      Grant-SystemFile $dst
      [System.IO.File]::Copy($old, $dst, $true)
      Write-Log "Tra lai ban cu $name"
    } catch {
      Write-Log "Khong tra duoc ${name}: $($_.Exception.Message)"
    }
  }
}

function Ensure-HttpDriver {
  $raw = & reg.exe query "HKLM\SYSTEM\CurrentControlSet\Services\HTTP" /v Start 2>$null | Out-String
  if ($raw -match "0x4") {
    Write-Log "HTTP dang Disabled. Dat lai Demand."
    & sc.exe config HTTP "start=" "demand" | Out-Null
  }
  & sc.exe start HTTP | Out-Null
  & sc.exe start RPCSS | Out-Null
}

function Invoke-ChacChan {
  Write-Log "===== SUA CHAC CHAN ====="
  $os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
  if ($os) { Write-Log ("Windows {0} build {1}" -f $os.Caption, $os.BuildNumber) }
  if ($os -and [int]$os.BuildNumber -ge 22000) {
    Write-Log "Day la Windows 11. File Spooler64 la Windows 10 19041. Neu khong len, tool se tra file .old."
  }
  Backup-SpoolerRegistry
  Stop-SpoolerHard
  $copied = Copy-BundleFiles
  if (-not $copied) { Write-Log "Co file khong thay duoc. Van ghi registry va thu start." }
  Restore-ServiceDefaults
  Repair-PrintStack
  Set-RpcPolicy
  Open-PrinterFirewall
  Clear-PrintQueue
  Ensure-HttpDriver
  if (Start-SpoolerChecked) {
    Write-Log "XONG. Doi khoang 2 phut roi ket noi lai may in."
    return
  }
  Write-Log "Ban moi khong chay. Dang tra file .old..."
  Stop-SpoolerHard
  Restore-OldFiles
  Restore-ServiceDefaults
  if (Start-SpoolerChecked) {
    Write-Log "Da tra file cu va spooler RUNNING. Loi nam o cho khac, khong phai 3 file nay."
  } else {
    Write-Log "Van chua chay. Khoi dong lai may, chay menu 1 lan nua. Log: $Log"
  }
}

function Invoke-FilesOnly {
  Write-Log "===== CHI THAY 3 FILE ====="
  Stop-SpoolerHard
  Copy-BundleFiles | Out-Null
  if (Start-SpoolerChecked) { Write-Log "XONG. Doi khoang 2 phut roi ket noi may in." }
  else { Write-Log "Chua len. Chay menu 1 de ghi luon registry Error 2." }
}

function Invoke-Error2 {
  Write-Log "===== ERROR 2 / DESCRIPTION ====="
  Backup-SpoolerRegistry
  Stop-SpoolerHard
  Restore-ServiceDefaults
  Repair-PrintStack
  Ensure-HttpDriver
  Start-SpoolerChecked | Out-Null
}

function Invoke-Rpc {
  Write-Log "===== RPC 0x11b / 0x7c / 0xbc4 ====="
  Set-RpcPolicy
  Stop-SpoolerHard
  Start-SpoolerChecked | Out-Null
}

function Invoke-Firewall {
  Write-Log "===== FIREWALL ====="
  & sc.exe config MpsSvc "start=" "auto" | Out-Null
  & sc.exe start MpsSvc | Out-Null
  Open-PrinterFirewall
}

function Invoke-ShareAll {
  Write-Log "===== CHIA SE MAY IN ====="
  $printers = @(Get-CimInstance -ClassName Win32_Printer -ErrorAction SilentlyContinue)
  if ($printers.Count -eq 0) { Write-Log "Khong tim thay may in."; return }
  foreach ($printer in $printers) {
    $share = -join ($printer.Name.ToCharArray() | Where-Object { $_ -match "[A-Za-z0-9_-]" })
    if ($share.Length -gt 12) { $share = $share.Substring(0, 12) }
    if (-not $share) { $share = "Printer" }
    Write-Log ("{0} => {1}" -f $printer.Name, $share)
    & rundll32.exe "printui.dll,PrintUIEntry" "/Xs" "/n" "$($printer.Name)" "Shared" "TRUE" "ShareName" "$share"
  }
}

function Invoke-709 {
  Write-Log "===== 0x00000709 ====="
  $win = "HKCU:\Software\Microsoft\Windows NT\CurrentVersion\Windows"
  try {
    $acl = Get-Acl $win
    $everyone = New-Object System.Security.Principal.SecurityIdentifier("S-1-1-0")
    $rule = New-Object System.Security.AccessControl.RegistryAccessRule(
      $everyone, "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")
    $acl.SetAccessRule($rule)
    Set-Acl -Path $win -AclObject $acl
    Write-Log "Da cap quyen khoa Windows cua user hien tai."
  } catch {
    Write-Log "Khong doi duoc ACL: $($_.Exception.Message)"
  }
  & reg.exe delete "HKCU\Software\Microsoft\Windows NT\CurrentVersion\Windows" /v Device /f | Out-Null
  & reg.exe add "HKCU\Software\Microsoft\Windows NT\CurrentVersion\Windows" /v LegacyDefaultPrinterMode /t REG_DWORD /d 1 /f | Out-Null
  Stop-SpoolerHard
  Start-SpoolerChecked | Out-Null
  Write-Log "Vao Settings dat lai may in mac dinh."
}

function Invoke-Policy {
  Write-Log "===== POINT AND PRINT ====="
  $k = "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Printers\PointAndPrint"
  & reg.exe add $k /v RestrictDriverInstallationToAdministrators /t REG_DWORD /d 0 /f | Out-Null
  & reg.exe add $k /v NoWarningNoElevationOnInstall /t REG_DWORD /d 1 /f | Out-Null
  & reg.exe add $k /v UpdatePromptSettings /t REG_DWORD /d 2 /f | Out-Null
  & reg.exe add $k /v InForest /t REG_DWORD /d 0 /f | Out-Null
  Stop-SpoolerHard
  Start-SpoolerChecked | Out-Null
}

function Invoke-LocalLink {
  Write-Log "===== 0x3e3 / LOCAL CONNECTION ====="
  & reg.exe add "HKLM\SYSTEM\CurrentControlSet\Control\Lsa" /v forceguest /t REG_DWORD /d 0 /f | Out-Null
  & reg.exe add "HKLM\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters" /v AllowInsecureGuestAuth /t REG_DWORD /d 1 /f | Out-Null
  Set-RpcPolicy
  Stop-SpoolerHard
  Start-SpoolerChecked | Out-Null
}

function Invoke-NetResource {
  Write-Log "===== 0xbcb ====="
  foreach ($svc in @("LanmanWorkstation", "LanmanServer")) {
    & sc.exe config $svc "start=" "auto" | Out-Null
    & sc.exe start $svc | Out-Null
  }
  Open-PrinterFirewall
  Stop-SpoolerHard
  Start-SpoolerChecked | Out-Null
}

function Copy-Mscms {
  $src = Join-Path $Sys "mscms.dll"
  foreach ($rel in @("spool\drivers\x64\3", "spool\drivers\w32x86\3")) {
    $dir = Join-Path $Sys $rel
    $dst = Join-Path $dir "mscms.dll"
    if ((Test-Path -LiteralPath $src) -and (Test-Path -LiteralPath $dir) -and -not (Test-Path -LiteralPath $dst)) {
      Copy-Item -LiteralPath $src -Destination $dst -Force
      Write-Log "Copy mscms.dll -> $rel"
    }
  }
}

function Invoke-DriverAndQueue {
  Write-Log "===== 0x7e / HANG DOI ====="
  Stop-SpoolerHard
  Copy-Mscms
  Clear-PrintQueue
  & sc.exe config Spooler "start=" "auto" | Out-Null
  Start-SpoolerChecked | Out-Null
}

function Invoke-RpcServices {
  Write-Log "===== 0x6ba ====="
  foreach ($svc in @("RpcSs", "RpcEptMapper")) {
    & sc.exe config $svc "start=" "auto" | Out-Null
    & sc.exe start $svc | Out-Null
  }
  Set-RpcPolicy
  Stop-SpoolerHard
  Start-SpoolerChecked | Out-Null
}

function Invoke-Offline {
  Write-Log "===== 0x771 OFFLINE ====="
  Get-WmiObject -Class Win32_Printer -ErrorAction SilentlyContinue |
    Where-Object { $_.WorkOffline -eq $true } |
    ForEach-Object {
      $_.WorkOffline = $false
      $_.Put() | Out-Null
      Write-Log "Da online: $($_.Name)"
    }
  Stop-SpoolerHard
  Clear-PrintQueue
  Start-SpoolerChecked | Out-Null
}

function Invoke-DismPrint {
  Write-Log "===== 0x3eb DISM ====="
  & dism.exe /Online /Enable-Feature /FeatureName:Printing-Foundation-InternetPrinting-Client /NoRestart
  & dism.exe /Online /Enable-Feature /FeatureName:Printing-LPRPortMonitor /NoRestart
  & dism.exe /Online /Enable-Feature /FeatureName:Printing-Foundation-LPDPrintService /NoRestart
  Stop-SpoolerHard
  Start-SpoolerChecked | Out-Null
}

function Invoke-Canon {
  Write-Log "===== CANON LBP ====="
  Stop-SpoolerHard
  Clear-PrintQueue
  & reg.exe delete "HKLM\SYSTEM\CurrentControlSet\Control\Print\Monitors\USB Monitor" /f | Out-Null
  $base = "HKLM:\SYSTEM\CurrentControlSet\Control\Print\Monitors"
  Get-ChildItem -LiteralPath $base -ErrorAction SilentlyContinue |
    Where-Object { $_.PSChildName -match "CNBJNP" } |
    ForEach-Object {
      Remove-Item -LiteralPath $_.PSPath -Recurse -Force -ErrorAction SilentlyContinue
      Write-Log "Xoa $($_.PSChildName)"
    }
  Copy-Mscms
  Start-SpoolerChecked | Out-Null
  Write-Log "Rut cap USB, doi 10 giay, cam lai."
}

function Invoke-ResetPorts {
  Write-Log "===== CONG TCP/IP HONG ====="
  $path = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Ports"
  $item = Get-ItemProperty -Path $path -ErrorAction SilentlyContinue
  if (-not $item) { Write-Log "Khong mo duoc khoa Ports."; return }
  $safe = @("usb", "lpt", "com", "file:", "nul", "portprompt", "xps")
  $removed = 0
  foreach ($prop in $item.PSObject.Properties) {
    $name = [string]$prop.Name
    if ($name.StartsWith("PS")) { continue }
    $low = $name.ToLowerInvariant()
    $keep = $false
    foreach ($prefix in $safe) {
      if ($low.StartsWith($prefix)) { $keep = $true }
    }
    if ($keep) { continue }
    if ($name.Contains(".") -or $name.Contains("\")) {
      Remove-ItemProperty -Path $path -Name $name -ErrorAction SilentlyContinue
      Write-Log "Xoa cong $name"
      $removed++
    }
  }
  Write-Log "Da xoa $removed cong. USB/COM/LPT giu nguyen."
  Stop-SpoolerHard
  Start-SpoolerChecked | Out-Null
}

function Invoke-UnlockShare {
  Write-Log "===== MO KHOA CHIA SE ====="
  & reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Printers" /v DisableHTTPPrinting /t REG_DWORD /d 0 /f | Out-Null
  & reg.exe add "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Printers" /v DisablePrinterAdmin /t REG_DWORD /d 0 /f | Out-Null
  Invoke-Policy
}

function Invoke-Diagnose {
  Write-Log "===== CHAN DOAN ====="
  $os = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
  if ($os) { Write-Log ("May: {0} | {1} | build {2}" -f $env:COMPUTERNAME, $os.Caption, $os.BuildNumber) }
  Write-Log "System32: $Sys"
  foreach ($name in $FileOrder) {
    $path = Join-Path $Sys $name
    if (-not (Test-Path -LiteralPath $path)) { Write-Log "THIEU $name"; continue }
    $item = Get-Item -LiteralPath $path
    $head = [System.IO.File]::ReadAllBytes($path)[0..1]
    $mz = ($head[0] -eq 77 -and $head[1] -eq 90)
    $ver = $item.VersionInfo.FileVersion
    Write-Log ("{0}  {1} bytes  MZ={2}  {3}" -f $name, $item.Length, $mz, $ver)
  }
  Write-Host (& sc.exe query Spooler | Out-String)
  Write-Host (& sc.exe qc Spooler | Out-String)
  & reg.exe query "HKLM\SYSTEM\CurrentControlSet\Services\Spooler" /v ImagePath
  & reg.exe query "HKLM\SYSTEM\CurrentControlSet\Control\Print" /v RpcAuthnLevelPrivacyEnabled
  Write-Log "Log day du: $Log"
}

function Get-SpoolerLabel {
  $query = ""
  try { $query = (& sc.exe query Spooler | Out-String) } catch {}
  if ($query -match "RUNNING") { return "ĐANG CHẠY" }
  if ($query -match "STOPPED") { return "ĐANG TẮT" }
  return "KHÔNG ĐỌC ĐƯỢC"
}

function Set-ConsoleFrame {
  try { $Host.UI.RawUI.WindowTitle = "Tân Thành Phát - Sửa lỗi máy in" } catch {}
  try {
    $ui = $Host.UI.RawUI
    $max = $ui.MaxWindowSize
    $width = [Math]::Min(96, [int]$max.Width)
    $height = [Math]::Min(42, [int]$max.Height)
    if ($width -lt 70) { return }
    $buf = $ui.BufferSize
    if ($buf.Width -lt $width) { $buf.Width = $width; $ui.BufferSize = $buf }
    $win = New-Object System.Management.Automation.Host.Size
    $win.Width = $width
    $win.Height = $height
    $ui.WindowSize = $win
  } catch {}
}

function Show-Head([string]$Section) {
  Clear-Host
  Write-Host ""
  Write-Host "  TÂN THÀNH PHÁT" -ForegroundColor Yellow
  Write-Host "  Thiết bị & Kỹ thuật máy văn phòng"
  Write-Host "  Sửa lỗi máy in"
  Write-Host ("  Máy {0}  |  Người {1}  |  Spooler {2}" -f $env:COMPUTERNAME, $env:USERNAME, (Get-SpoolerLabel))
  if ($Section) { Write-Host "" ; Write-Host "  $Section" -ForegroundColor Yellow }
  Write-Host "  ------------------------------------------------------------"
}

function Show-Job([hashtable]$Job) {
  Write-Host ""
  Write-Host ("  {0}  {1}" -f $Job.Key, $Job.Title)
  Write-Host ("     Khi nào: {0}" -f $Job.When)
  Write-Host ("     Sẽ làm:  {0}" -f $Job.Does)
}

function Invoke-Picked([hashtable]$Job) {
  Show-Head $Job.Title
  Write-Host ""
  Write-Host ("  Khi nào: {0}" -f $Job.When)
  Write-Host ("  Sẽ làm:  {0}" -f $Job.Does)
  Write-Host ("  Không đụng: {0}" -f $Job.Safe)
  Write-Host ""
  $answer = Read-Host "  Gõ C để chạy việc này. Enter để quay lại"
  if ($answer -ne "C" -and $answer -ne "c") { return }
  Write-Host ""
  & $Job.Run
  Write-Host ""
  Write-Host "  Xong việc này."
  Write-Host "  Log: $Log"
  Read-Host "  Enter để về menu" | Out-Null
}

function Show-Group([string]$Title, [string]$Hint, [object[]]$Jobs) {
  while ($true) {
    Show-Head $Title
    Write-Host "  $Hint"
    foreach ($job in $Jobs) { Show-Job $job }
    Write-Host ""
    Write-Host "  0  Quay lại. Chưa sửa gì."
    Write-Host "  ------------------------------------------------------------"
    $pick = (Read-Host "  Chọn số").Trim()
    if ($pick -eq "0" -or $pick -eq "") { return }
    $job = $Jobs | Where-Object { $_.Key -eq $pick } | Select-Object -First 1
    if (-not $job) {
      Write-Host "  Không có số này. Chọn đúng số in trên màn hình."
      Start-Sleep -Seconds 1
      continue
    }
    Invoke-Picked $job
  }
}

Set-ConsoleFrame
"" | Set-Content -LiteralPath $Log -Encoding UTF8
Write-Log "Sua loi may in | $env:COMPUTERNAME | $env:USERNAME"

$Gap = @(
  @{
    Key = "1"; Title = "Sửa chắc chắn"
    When = "Print Spooler không Start, Error 2, hoặc không đọc được mô tả dịch vụ."
    Does = "Dừng dịch vụ, thay 3 file, ghi lại cấu hình, bật chia sẻ, xóa hàng đợi. File mới không chạy thì trả file cũ."
    Safe = "Driver và các máy in đã cài."
    Run = { Invoke-ChacChan }
  }
  @{
    Key = "2"; Title = "Chỉ thay 3 file spooler"
    When = "spoolsv.exe mất hoặc hỏng. Services báo không tìm thấy file."
    Does = "Đổi 3 file hiện tại thành .old, rồi chép bản trong thư mục Spooler64 vào System32."
    Safe = "Chính sách mạng và driver."
    Run = { Invoke-FilesOnly }
  }
  @{
    Key = "3"; Title = "Sửa Error 2, giữ file đang dùng"
    When = "File vẫn còn trên đĩa, nhưng bấm Start vẫn Error 2 hoặc mất mô tả dịch vụ."
    Does = "Ghi lại đường dẫn spoolsv.exe và mô tả dịch vụ. Có bản backup registry trước khi ghi."
    Safe = "Không ghi đè spoolsv.exe, localspl.dll, win32spl.dll."
    Run = { Invoke-Error2 }
  }
)

$Server = @(
  @{
    Key = "1"; Title = "Máy khác không thêm được máy in, 0x11b / 0x7c / 0xbc4"
    When = "Thêm máy in mạng thì báo 0x0000011b, 0x0000007c hoặc 0x00000bc4."
    Does = "Mở RPC in mạng trên máy đang chia sẻ, rồi khởi động lại Print Spooler."
    Safe = "Không xóa máy in."
    Run = { Invoke-Rpc }
  }
  @{
    Key = "2"; Title = "Máy khác không thấy máy in, firewall 0x6d9 / 0x40"
    When = "Ping được nhưng không thấy máy in, hoặc lỗi 0x000006d9 vì firewall đang tắt."
    Does = "Bật dịch vụ Windows Firewall và nhóm chia sẻ file, máy in. Không tắt firewall."
    Safe = "Không mở mọi cổng."
    Run = { Invoke-Firewall }
  }
  @{
    Key = "3"; Title = "Bật chia sẻ mọi máy in trên máy này"
    When = "In tại máy này được, nhưng máy khác không có đường dẫn \\máy\tên."
    Does = "Bật Share và đặt tên share ngắn, không dấu cách, tối đa 12 ký tự."
    Safe = "Không đổi driver."
    Run = { Invoke-ShareAll }
  }
  @{
    Key = "4"; Title = "Nút Share this printer bị mờ"
    When = "Vào Sharing thấy nút khóa, hoặc chính sách không cho quản trị máy in."
    Does = "Gỡ policy cấm chia sẻ và cấm in qua HTTP, rồi nới cài driver trong mạng."
    Safe = "Không đổi mật khẩu máy."
    Run = { Invoke-UnlockShare }
  }
  @{
    Key = "5"; Title = "Mọi lệnh in báo 0x6ba"
    When = "Lỗi 0x000006ba vì dịch vụ RPC đang tắt."
    Does = "Bật RpcSs và RpcEptMapper, rồi khởi động lại Print Spooler."
    Safe = "Không sửa file spooler."
    Run = { Invoke-RpcServices }
  }
)

$Client = @(
  @{
    Key = "1"; Title = "Không đặt được máy in mặc định, 0x709"
    When = "Chọn máy in mặc định không được, lỗi 0x00000709."
    Does = "Xóa máy in mặc định cũ và bật lại kiểu đặt mặc định của Windows."
    Safe = "Không gỡ driver. Xong việc, bạn chọn lại máy in mặc định bằng tay."
    Run = { Invoke-709 }
  }
  @{
    Key = "2"; Title = "Windows chặn cài driver từ máy chủ, 0x4005"
    When = "Mở \\máy-chủ\máy-in thì Access denied, hoặc hiện hộp thoại chính sách."
    Does = "Cho phép cài driver in từ máy chủ trong cùng mạng. Mật khẩu phải tự gõ."
    Safe = "Tool không lưu mật khẩu."
    Run = { Invoke-Policy }
  }
  @{
    Key = "3"; Title = "Hai máy không cùng domain, 0x3e3"
    When = "Thấy share nhưng in không được, lỗi 0x000003e3."
    Does = "Cho máy trong cùng workgroup mở được share, tắt chế độ ép khách."
    Safe = "Không đổi tên máy."
    Run = { Invoke-LocalLink }
  }
  @{
    Key = "4"; Title = "Không mở được \\máy-chủ, 0xbcb"
    When = "Ping được nhưng không vào đường dẫn máy in, lỗi 0x00000bcb."
    Does = "Bật hai dịch vụ mở thư mục mạng: Workstation và Server."
    Safe = "Không xóa cổng máy in."
    Run = { Invoke-NetResource }
  }
  @{
    Key = "5"; Title = "Thiếu file driver, 0x7e"
    When = "Thêm máy in xong báo 0x0000007e."
    Does = "Bổ sung mscms.dll nếu thư mục driver thiếu, và xóa job đang kẹt."
    Safe = "Không gỡ driver đang cài."
    Run = { Invoke-DriverAndQueue }
  }
  @{
    Key = "6"; Title = "Máy này kết nối sang cũng bị 0x11b / 0xbc4"
    When = "Máy trạm thêm máy in của máy chủ thì báo 0x0000011b hoặc 0x00000bc4."
    Does = "Mở RPC in mạng trên chính máy trạm, rồi khởi động lại spooler."
    Safe = "Nên chạy mục tương tự trên máy chủ."
    Run = { Invoke-Rpc }
  }
)

$Local = @(
  @{
    Key = "1"; Title = "Hàng đợi kẹt, không xóa được job, 0x12"
    When = "Máy in đứng, job không xóa được, hoặc lỗi 0x00000012."
    Does = "Xóa file tạm trong hàng đợi và bật lại Print Spooler."
    Safe = "Không xóa driver."
    Run = { Invoke-DriverAndQueue }
  }
  @{
    Key = "2"; Title = "Máy in đang Offline, 0x771"
    When = "Máy in mờ, trạng thái Offline, dù cáp và nguồn vẫn có."
    Does = "Đưa máy in về online và xóa job kẹt."
    Safe = "Không đổi cổng USB."
    Run = { Invoke-Offline }
  }
  @{
    Key = "3"; Title = "Thiếu in qua LPR hoặc IPP, 0x3eb"
    When = "Thêm cổng LPR hoặc máy in IPP thì báo 0x000003eb."
    Does = "Bật Internet Printing Client và LPR Port Monitor. Có thể mất vài phút."
    Safe = "Không bắt buộc khởi động lại máy ngay."
    Run = { Invoke-DismPrint }
  }
  @{
    Key = "4"; Title = "Canon LBP 2900 hoặc 3300 không ra giấy"
    When = "Báo Communication Error: nhận cổng nhưng không in."
    Does = "Xóa cổng USB Monitor và CNBJNP cũ, giữ driver. Rút cáp 10 giây rồi cắm lại."
    Safe = "Không cài đè driver khác."
    Run = { Invoke-Canon }
  }
  @{
    Key = "5"; Title = "Cổng mạng TCP/IP trùng hoặc sai IP"
    When = "Thêm máy in mạng không được vì cổng Standard TCP/IP hỏng."
    Does = "Chỉ xóa cổng có địa chỉ IP hoặc đường \\máy. Giữ USB, COM, LPT."
    Safe = "Không xóa cả danh sách cổng."
    Run = { Invoke-ResetPorts }
  }
)

while ($true) {
  Show-Head "Chọn đúng chỗ đang đứng"
  $state = Get-SpoolerLabel
  if ($state -eq "ĐANG TẮT") {
    Write-Host "  Gợi ý: Spooler đang TẮT. Services không Start hoặc Error 2 thì chọn 4."
  } else {
    Write-Host "  Gợi ý: Spooler đang CHẠY. Chọn máy chủ, máy trạm, hoặc máy in cắm tại chỗ."
  }
  Write-Host "  Đọc kỹ hai dòng Khi nào và Sẽ làm. Chưa gõ C thì tool chưa sửa gì."
  Write-Host ""
  Write-Host "  1  Máy chủ in"
  Write-Host "     Đứng ở máy đang chia sẻ máy in cho máy khác."
  Write-Host "     Dùng khi: 0x11b, 0x7c, không share được, firewall, 0x6ba."
  Write-Host ""
  Write-Host "  2  Máy trạm"
  Write-Host "     Đứng ở máy đang kết nối vào máy in của máy khác."
  Write-Host "     Dùng khi: 0x709, 0x4005, 0x3e3, 0xbcb, 0x7e."
  Write-Host ""
  Write-Host "  3  Máy in cắm tại chỗ"
  Write-Host "     USB, Canon LBP, hàng đợi kẹt, máy in Offline, cổng TCP/IP sai."
  Write-Host ""
  Write-Host "  4  Spooler không lên / Error 2"
  Write-Host "     Services không Start, Failed to Read Description, file spooler mất."
  Write-Host "     Mục này thay file và ghi lại dịch vụ. Có trả lại file cũ nếu không chạy."
  Write-Host ""
  Write-Host "  5  Chỉ xem máy, chưa sửa"
  Write-Host "     In trạng thái dịch vụ và 3 file. Không ghi đè, không đổi chính sách."
  Write-Host ""
  Write-Host "  0  Thoát"
  Write-Host "  ------------------------------------------------------------"
  $choice = (Read-Host "  Chọn số").Trim()
  switch ($choice) {
    "1" { Show-Group "Máy chủ đang chia sẻ máy in" "Chọn đúng lỗi máy khác đang gặp khi vào máy in của máy này." $Server }
    "2" { Show-Group "Máy trạm đang kết nối máy in" "Chọn đúng lỗi trên máy này khi nối sang máy in của máy khác." $Client }
    "3" { Show-Group "Máy in USB hoặc tại quầy" "Chọn đúng việc đang kẹt tại máy này." $Local }
    "4" { Show-Group "Spooler không lên hoặc Error 2" "Không rõ file mất hay chỉ sai đường dẫn: chọn 1. File chắc chắn mất: chọn 2." $Gap }
    "5" {
      Show-Head "Chỉ xem, chưa sửa"
      Write-Host "  Việc này không thay file, không đổi registry."
      Write-Host ""
      Invoke-Diagnose
      Write-Host ""
      Read-Host "  Enter để về menu" | Out-Null
    }
    "0" { exit 0 }
    default {
      Write-Host "  Không có số này. Chọn 1, 2, 3, 4, 5 hoặc 0."
      Start-Sleep -Seconds 1
    }
  }
}
