@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
title Sua loi may in
net session >nul 2>&1
if not "%errorlevel%"=="0" (
    echo Dang mo quyen Administrator...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Sua-Loi-May-In.ps1"
echo.
pause
